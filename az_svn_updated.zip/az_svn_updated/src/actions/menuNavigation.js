const menuNavigation = [
  {
    id: 'Accessories',
    name: 'Accessories',
    link: 'https://en.wikipedia.org/wiki/Driulis_González'
  },
  {
    id: 'AutoParts',
    name: 'AutoParts',
    link: 'https://en.wikipedia.org/wiki/Mark_Huizinga'
  },
  {
    id: 'Tools',
    name: 'Tools',
    link: 'https://en.wikipedia.org/wiki/Rishod_Sobirov'
  },
  {
    id: 'HotDeals',
    name: 'HotDeals',
    link: 'https://en.wikipedia.org/wiki/Ryoko_Tani'
  },
  {
    id: 'Bowers',
    name: 'Bowers',
    link: 'https://en.wikipedia.org/wiki/Teddy_Riner'
  }
];

export default menuNavigation;
