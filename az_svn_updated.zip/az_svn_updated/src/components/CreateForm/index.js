/* eslint-disable */
import React, { PureComponent } from 'react';
import type from 'react';
import TextField from 'material-ui/TextField';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton';
import PasswordField from 'material-ui-password-field';
// import type { Connector } from 'react-redux';
import { Field, reduxForm, formValueSelector } from 'redux-form';
import { connect } from 'react-redux';
import * as styles from '../../containers/CreateAccount/styles.scss';
import validate from './validation';

type Props = {
  label: string,
  data: Object,
  input: Object,
  formValues: Object,
  meta: Object
};

const styles1 = {
  floatingLabelFocusStyle: {
    background: 'white',
    height: '20px',    
    padding: '0 5px'      
  },
  errorInputStyle: {
    bottom: '7px',    
    left: '-14px',
    color: '#CF1322'
  },
  borderGrey: {
    border: '1px solid #ccc'
  },
  errorUnderline: {
    border: '1px solid $autozone-red',
    left: 0,
    bottom: 0,
    opacity: 1,
    display: 'block',
    width: '100%'
  },
  errorUnderlinePwd: {
    border: '1px solid $autozone-red',
    left: '-1px',
    bottom: '-1px',
    opacity: 1,
    display: 'block',
    width: '100%'
  },
  labelStyle: {
    height: '13px',
    top: 0,
    bottom: 0,
    margin: 'auto'
   },
   labelShrinkStyle: {
    height: '22px'
   }
};

const renderTextField = ({ label, input, meta: { touched, error } }: Props) => {
  console.log('label', label);
  return (<TextField
    floatingLabelText={label}
    hintText={label}
    className={styles.inputTextBox}
    floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
    errorStyle={styles1.errorInputStyle}
    errorText={touched && error}
    inputStyle={styles1.borderGrey}
    floatingLabelStyle={styles1.labelStyle}
    floatingLabelShrinkStyle={styles1.labelShrinkStyle}
    underlineFocusStyle={styles1.errorUnderline}
    {...input}
  />)
};

const renderPasswordField = ({ label, input, meta: { touched, error } }: Props) =>
  {
    return (<PasswordField
    floatingLabelText={label}
    className={styles.inputTextBox_Password}
    errorStyle={styles1.errorInputStyle}
    visibilityIconStyle={{
      marginTop: '-10px',
      opacity: '1'
    }}    
    floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
    fullWidth
    textFieldStyle={styles1.borderGrey}
    floatingLabelStyle={styles1.labelStyle}
    floatingLabelShrinkStyle={styles1.labelShrinkStyle}  
    underlineFocusStyle={styles1.errorUnderlinePwd}
    errorText={touched && error}
    {...input}
  />)
};

const renderCheckbox = ({ input, label }) => (
  <Checkbox
    label={label}
    checked={input.value ? true : false}
    onCheck={input.onChange}
    {...input}
  />
)

const renderRewardTextField = ({ label, input, meta: { touched, error } }: Props) => {
  console.log('label', label);
  return (<TextField
    hintText="9101000389891796"
    className={styles.rewardsText}
    floatingLabelText="Autozone Rewards Member ID"
    floatingLabelStyle={{
                top: '29px',
                left: '15px',
                fontWeight: 'normal',
                border: 'none'
              }}
              floatingLabelFocusStyle={{
                color: '#a9aaa8',
                left: '15px',
                paddingBottom: '5px'
              }}
              style={{
                width: '100%',
                height: '56px',
                border: '1px solid black'
              }}
    errorText={touched && error}
    errorStyle={styles1.errorInputStyle}
    {...input}
  />)
};

class CreateForm extends PureComponent<Props> {

  submitFormHandler = () => {
    console.log('submitFormHandler');
    const { handleSubmit, SubmitStatus} = this.props;
    handleSubmit();
    if (SubmitStatus) {
      console.log('SubmitStatus ', SubmitStatus);
    }
  }
  render() {
    console.log('CreateForm props', this.props);
    const { data, handleSubmit, pristine, reset, submitting } = this.props;
    return (
      <form>
        <div>
          <div style={{ paddingBottom: '20px' }}>
            <Field
              name="firstName"
              component={renderTextField}
              label={data.mf_registration_firstName_desktop_lbl}
            />
            <Field
              name="lastName"
              component={renderTextField}
              label={data.mf_registration_lastName_desktop_lbl}
            />
            <Field
              name="postalCode"
              component={renderTextField}
              label={data.mf_registration_zip_desktop_lbl}
            />
            <Field
              name="phoneNumber"
              component={renderTextField}
              label={data.mf_registration_phone_desktop_lbl}
            />
            <Field
              name="email"
              component={renderTextField}
              label={data.mf_registration_email_desktop_lbl}
            />
            <Field
              name="password"
              component={renderPasswordField}
              label={data.mf_registration_password_desktop_lbl}
            />
          </div>
          <div className={styles.regRewardSection}>
            <div className={styles.regRewardSectionTop}>
              {data.mf_registration_rewards_header_lbl}
              <img
                className={styles.rewardsArrow}
                src={require('../../containers/CreateAccount/assets/rewardsArrow.png')}
                alt="Logo"
                role="presentation"
              />
            </div>
            <div className={styles.regRewardSectionMid}>
              {data.mf_registration_rewards_msg}
            </div>
            <Field
              name="reward"
              component={renderRewardTextField}
            />
            <div className={styles.regAZMember_Error}>
              We couldn’t find that ID number. Check against the back of your
              card and try again?
            </div>
          </div>
          <div className={styles.regSubscription}>
            <div className={styles.offerCheckBox}>
              <Field name="subscribe" component={renderCheckbox} />
            </div>
            <div className={styles.receiveOffer}>
              {data.mf_registration_privacy_msg_1}
              <a
                href="/readYourPolicy"
                style={{
                  display: 'block',
                  textDecoration: 'underline',
                  color: '#333'
                }}
              >
                {data.mf_registration_privacy_msg_2}
              </a>
            </div>
            <div className={styles.regReadTerms}>
              {data.mf_registration_TermsandConditions_msg_1}
              <a href="/termsAndConditions">
                {data.mf_registration_TermsandConditions_msg_2}
              </a>
            </div>
            <div className={styles.regButtonSection}>
              <RaisedButton
                onClick={this.submitFormHandler}
                disabled={pristine || submitting}
                label={data.mf_registration_createAccount_btn}
                className={styles.regPrimaryBtn}
              />
              <RaisedButton
                disabled={pristine || submitting}
                label={data.mf_registration_cancel_lbl}
                className={styles.regSecondaryBtn}
              />
            </div>
            <div className={styles.regSignInLink}>
              {data.mf_registration_signIn_msg_1}
              <a href="/signIn">{data.mf_registration_signIn_msg_2}</a>
            </div>
          </div>
        </div>
      </form>
    );
  }
}

CreateForm = reduxForm({
  form: 'createFormValues',
  validate
})(CreateForm);
const selector = formValueSelector('createFormValues');

CreateForm = connect(state => {
  console.log('STAte', state);
  return {
    initialValues: state.formInfo.defaultFormData,
    formValues: state.form.createFormValues && state.form.createFormValues.values,
    SubmitStatus: state.formInfo.SubmitStatus
  };
})(CreateForm);

export default CreateForm;
