/* eslint-disable */
import React, { PureComponent } from 'react';
import type from 'react';
import TextField from 'material-ui/TextField';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton';
import PasswordField from 'material-ui-password-field';
import type { Connector } from 'react-redux';
import { Field, reduxForm, formValueSelector } from 'redux-form';
import { connect } from 'react-redux';
import * as styles from '../../containers/CreateAccount/styles.scss';

type Props = {
  label: string,
  props: Object,
  data: Object,
  formInfo: Object
};

const initialState = {
  login: '',
  password: 'test_password',
  email: 'testragu@gmail.com',
  firstName: 'Ragu',
  lastName: 'Sundaram',
  addresses: [
    {
      items: {
        type: 'test_homeAddress',
        postalCode: '12345209',
        phoneNumber: '9876543210'
      }
    }
  ],
  otherOptions: {
    mobileApp: 'true',
    activeSubscriptionsAsCSV: 'test_receivePromoAndSpecialEvents'
  }
};

const styles1 = {
  floatingLabelFocusStyle: {
    background: 'white',
    height: '25px',
    margintop: '12px',
    padding: '0 5px',
    lineHeight: '1px !important'
  }
};

const renderTextField = ({ props, label }: Props) => (
  <input />
);

const renderPasswordField = ({ props, label }: Props) => (
  <PasswordField
    hintText={label}
    floatingLabelText={label}
    className={styles.inputTextBox_Password}
    visibilityIconStyle={{
      marginTop: '-10px',
      opacity: '1'
    }}
    floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
    {...props}
  />
);

const handleSubmit = ({ formInfo }: Props) => {
  console.log('in submit');
  console.log('the formValues are', formInfo);

  // const formData = document.getElementsByTagName('form')[0];
  // const { elements } = formData;
  // console.log(
  //   elements.namedItem('firstName') && elements.namedItem('firstName').value
  // );
};

class CreateForm extends PureComponent<Props> {



  render() {

    return (
      <form onSubmit={handleSubmit}>
      <div>
        <label>First Name</label>
        <div>
          <Field
            name="firstName"
            component="input"
            type="text"
            placeholder="First Name"
          />
        </div>
      </div>
      <div>
        <label>Last Name</label>
        <div>
          <Field
            name="lastName"
            component="input"
            type="text"
            placeholder="Last Name"
          />
        </div>
      </div>
      <div>
        <label>Email</label>
        <div>
          <Field
            name="email"
            component="input"
            type="email"
            placeholder="Email"
          />
        </div>
      </div>
      <div>
        <label>Sex</label>
        <div>
          <label>
            <Field name="sex" component="input" type="radio" value="male" />
            {' '}
            Male
          </label>
          <label>
            <Field name="sex" component="input" type="radio" value="female" />
            {' '}
            Female
          </label>
        </div>
      </div>
      <div>
        <label>Favorite Color</label>
        <div>
          <Field name="favoriteColor" component="select">
            <option />
            <option value="ff0000">Red</option>
            <option value="00ff00">Green</option>
            <option value="0000ff">Blue</option>
          </Field>
        </div>
      </div>
      <div>
        <label htmlFor="employed">Employed</label>
        <div>
          <Field
            name="employed"
            id="employed"
            component="input"
            type="checkbox"
          />
        </div>
      </div>
      <div>
        <label>Notes</label>
        <div>
          <Field name="notes" component="textarea" />
        </div>
      </div>
      <div>
        <button type="submit">Submit</button>
      </div>
    </form>
    );
  }
}

// const CreateForm = ({
//   props,
//   data,
//   formInfo,
//   label
// }: Props): Element<'form'> => {
//   console.log('Create Form props', props, data, formInfo, label);
//   return (
//
//   );
// };

// const getFormValues = (state) => {
//   console.log('CreateForm State', state.CreateForm);
// }

CreateForm = reduxForm({
  form: 'simpel'
})(CreateForm);
const selector =formValueSelector('simpel');

CreateForm = connect(state => {
  console.log(state);
  window.stateObj = state;
  // console.log('initialState', initialState);
  console.log('simpel', selector(state, 'firstName'));
  return ({
   initialValues: {
     'firstName': 'Joe'
   }
//   initialState
})})(CreateForm)

// const connector: Connector<{}, Props> = connect(
//   ({ createAccountData }: ReduxState) => ({
//     createAccountData
//   })
// );

// export default connect(state => ({
//   initialState,
//   formValues:  getFormValues(state)
// }))(CreateForm);

export default CreateForm;
