/* @flow */

import React, { PureComponent } from 'react';
import type { Element } from 'react';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import type {
  CreateAccountData as CreateAccountDataType,
  Dispatch,
  ReduxState
} from '../../types';
import CreateForm from '../../components/CreateForm';
import * as styles from './styles.scss';
import * as createAccount from '../../actions/createAccount';
import * as submitForm from '../../actions/submitForm';
import Banner from './Banner';

type Props = {
  createAccountData: CreateAccountDataType,
  fetchCreateAccountData: () => void,
  submitFormAction: () => void
};

// Export this for unit testing more easily
export class CreateAccount extends PureComponent<Props> {
  componentDidMount() {
    console.log('the fetch', this.props);
    this.props.fetchCreateAccountData();
  }

  handleSubmit = formInfo => {
    console.log('in submit');
    console.log('the formValues are', formInfo);

    const formValues = {
      login: '',
      password: formInfo.password,
      email: formInfo.email,
      firstName: formInfo.firstName,
      lastName: formInfo.lastName,
      addresses: [
        {
          items: {
            type: 'test_homeAddress',
            postalCode: formInfo.postalCode,
            phoneNumber: formInfo.phoneNumber
          }
        }
      ],
      otherOptions: {
        mobileApp: 'true',
        activeSubscriptionsAsCSV: 'test_receivePromoAndSpecialEvents'
      }
    };

    console.log('formValues', formValues);
    this.props.submitFormAction(formValues);
  };

  // showResults = values => {
  //   console.log('Inside showResults()', values);
  //   console.log(`You submitted:\n\n${JSON.stringify(values, null, 2)}`);
  // };

  renderCreateForm = (): Element<'p' | typeof CreateForm> => {
    const { createAccountData } = this.props;
    // console.log('ACTION', createAccountData);
    if (
      !createAccountData.readyStatus ||
      createAccountData.readyStatus === 'CREATE_INVALID' ||
      createAccountData.readyStatus === 'CREATE_REQUESTING'
    ) {
      return <p>Loading...</p>;
    }

    if (createAccountData.readyStatus === 'CREATE_FAILURE') {
      return <p>Oops, Failed to load list!</p>;
    }

    return (
      <CreateForm
        data={createAccountData.viewInfo}
        onSubmit={this.handleSubmit}
      />
    );
  };

  render() {
    const { createAccountData } = this.props;
    console.log('createAccountData in Container', createAccountData);

    return (
      <div className={styles.regMainContainer}>
        <div className={styles.registerationPage}>
          <div className="row">
            <div className="col s12 m12 l5 xl5">
              <div className={styles.regLeftSection}>
                <img
                  style={{
                    display: 'block',
                    position: 'relative',
                    left: '-18px'
                  }}
                  src={require('./assets/backBtn.png')}
                  alt="Logo"
                  role="presentation"
                  width="90px"
                  height="58px"
                />
                <div style={{ paddingTop: '20px' }}>
                  <img
                    src={require('./assets/logo-mobile.png')}
                    alt="Logo"
                    role="presentation"
                    height="43px"
                    className="show-on-small hide-on-med-and-up"
                  />
                  <img
                    src={require('./assets/Autozonelogo.png')}
                    alt="Logo"
                    role="presentation"
                    height="43px"
                    className="hide-on-small-only"
                  />
                </div>
                <h1 style={{ paddingBottom: '10px' }}>
                  {createAccountData.viewInfo.mf_registration_page_header_lbl}
                </h1>
                <div>{this.renderCreateForm()}</div>
              </div>
            </div>
            <div className="col l7 xl7 hide-on-med-and-down hide-on-small-only">
              <div className={styles.regRightGrid}>
                <Banner data={createAccountData.viewInfo} />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ createAccountData }: ReduxState) => ({
    createAccountData
  }),
  (dispatch: Dispatch) => ({
    fetchCreateAccountData: () =>
      dispatch(createAccount.fetchCreateAccountData()),
    submitFormAction: values => dispatch(submitForm.submitFormAction(values))
  })
);

export default connector(CreateAccount);
