/* @flow */

import React, { PureComponent } from 'react';
import type { Element } from 'react';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import Helmet from 'react-helmet';
import * as NavAction from '../../actions/navAction';
import type { NavInfo as NavInfoType, Dispatch, ReduxState } from '../../types';
import TestCard from '../../components/TestCard';

type Props = {
  navInfo: NavInfoType,
  match: Object,
  fetchUserIfNeeded: (title: string) => void
};

// Export this for unit testing more easily
export class NavInfo extends PureComponent<Props> {
  componentDidMount() {
    const { fetchUserIfNeeded, match } = this.props;
    fetchUserIfNeeded(match.params.title);
  }

  renderTestCard = (): Element<'p' | typeof TestCard> => {
    const { navInfo, match: { params } } = this.props;
    const navInfoById = navInfo[params.title];

    if (!navInfoById || navInfoById.readyStatus === 'USER_REQUESTING') {
      return <p>Loading...</p>;
    }

    if (navInfoById.readyStatus === 'USER_FAILURE') {
      return <p>Oops, Failed to load info!</p>;
    }

    return <TestCard info={navInfoById.info} />;
  };

  render() {
    return (
      <div>
        <Helmet title="Nav Info" />
        {this.renderTestCard()}
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ navInfo }: ReduxState) => ({ navInfo }),
  (dispatch: Dispatch) => ({
    fetchUserIfNeeded: (title: string) =>
      dispatch(NavAction.fetchUserIfNeeded(title))
  })
);

export default connector(NavInfo);
