/* @flow */

import _ from 'lodash/fp';

import type { CreateAccountData, Action } from '../types';

type State = CreateAccountData;

const initialState = {
  readyStatus: 'CREATE_INVALID',
  err: null,
  viewInfo: {}
};

export default (state: State = initialState, action: Action): State => {
  // console.log('Create Account Reducer', action, state);
  switch (action.type) {
    case 'CREATE_REQUESTING':
      return _.assign(state, {
        readyStatus: 'CREATE_REQUESTING'
      });
    case 'CREATE_FAILURE':
      return _.assign(state, {
        readyStatus: 'CREATE_FAILURE',
        err: action.err
      });
    case 'CREATE_SUCCESS':
      return _.assign(state, {
        readyStatus: 'CREATE_SUCCESS',
        viewInfo: action.data
      });
    default:
      return state;
  }
};
