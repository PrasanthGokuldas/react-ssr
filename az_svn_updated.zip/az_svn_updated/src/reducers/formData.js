/* @flow */

import _ from 'lodash/fp';

import type { FormData, Action } from '../types';

type State = FormData;

const initialState = {
  defaultFormData: {
    login: '',
    password: '',
    email: '',
    firstName: '',
    lastName: '',
    postalCode: '',
    phoneNumber: '',
    subscribe: true,
    reward: ''
  },
  SubmitStatus: false
};

export default (state: State = initialState, action: Action): State => {
  switch (action.type) {
    case 'SUBMIT_REQUESTING':
      return _.assign(state, {
        readyStatus: 'SUBMIT_REQUESTING'
      });
    case 'SUBMIT_FAILURE':
      return _.assign(state, {
        readyStatus: 'SUBMIT_FAILURE',
        err: action.err
      });
    case 'SUBMIT_SUCCESS':
      console.log('SUBMIT_SUCCESS', action.data);
      return _.assign(state, {
        readyStatus: 'SUBMIT_SUCCESS',
        successValues: action.data,
        SubmitStatus: true
      });
    default:
      return state;
  }
};
