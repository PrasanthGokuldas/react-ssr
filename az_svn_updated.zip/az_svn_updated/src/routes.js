/* @flow */

import type { Dispatch } from './types';
import { fetchUsersIfNeeded } from './actions/users';
import { fetchUserIfNeeded } from './actions/user';
// import { fetchCreateAccountData } from './actions/createAccount';
import HomePage from './containers/Home';
import UserInfoPage from './containers/UserInfo';
import NotFoundPage from './containers/NotFound';
import NavInfoPage from './containers/NavInfo';
import Confirmation from './containers/CreateAccount/Confirmation';
import CreateAccountPage from './containers/CreateAccount';

export default [
  {
    path: '/',
    exact: true,
    component: HomePage, // Add your route here
    loadData: (dispatch: Dispatch) =>
      Promise.all([
        dispatch(fetchUsersIfNeeded()) // Register your server-side call action(s) here
      ])
  },

  {
    path: '/UserInfo/:id',
    component: UserInfoPage,
    loadData: (dispatch: Dispatch, params: Object) =>
      Promise.all([dispatch(fetchUserIfNeeded(params.id))])
  },

  {
    path: '/Home/:title',
    component: NavInfoPage,
    loadData: (dispatch: Dispatch, params: Object) =>
      Promise.all([dispatch(fetchUserIfNeeded(params.title))])
  },

  {
    path: '/CreateAccountPage',
    component: CreateAccountPage
  },

  {
    path: '/Confirmation',
    component: Confirmation
  },

  {
    path: '*',
    component: NotFoundPage
  }
];
