/* @flow */

// Decalre your global variables type here for flow checking
declare var __CLIENT__: bool;
declare var __SERVER__: bool;
declare var __DISABLE_SSR__: bool;
declare var __DEV__: bool;
declare var webpackIsomorphicTools: any;
declare var should: any;
declare var expect: any;
declare var assert: any;
