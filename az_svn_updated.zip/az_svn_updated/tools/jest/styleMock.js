import idObj from 'identity-obj-proxy';

export default idObj;
