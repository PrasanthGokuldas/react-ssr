/* eslint-disable */
import React, { PureComponent } from 'react';
import type from 'react';
import TextField from 'material-ui/TextField';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton';
import PasswordField from 'material-ui-password-field';
// import type { Connector } from 'react-redux';
import { Field, reduxForm, formValueSelector } from 'redux-form';
import { connect } from 'react-redux';
import { Accordion, Icon } from 'semantic-ui-react'
import * as styles from '../../containers/CreateAccount/styles.scss';
import validate from './validation';

type Props = {
  label: string,
  data: Object,
  input: Object,
  formValues: Object,
  meta: Object
};

const styles1 = {
  floatingLabelFocusStyle: {
    background: 'white',
    height: '20px',
    padding: '0 5px'
  },
  errorInputStyle: {
    top: '-95px',
    left: '-14px',
    color: '#CF1322'
  },
  errorInputStyleRewards: {
    top: '-75px',
    color: '#CF1322'
  },
  borderGrey: {
    border: '1px solid #ccc'
  },
  errorUnderline: {
    border: '1px solid $autozone-red',
    left: 0,
    bottom: 0,
    opacity: 1,
    display: 'block',
    width: '100%'
  },
  errorUnderlinePwd: {
    border: '1px solid $autozone-red',
    left: '-1px',
    bottom: '-1px',
    opacity: 1,
    display: 'block',
    width: '100%'
  },
  labelStyle: {
    height: '13px',
    top: 0,
    bottom: 0,
    margin: 'auto'
   },
   labelShrinkStyle: {
    height: '20px'
   }

};

const renderTextField = ({ label, input, meta: { touched, error } }: Props) => {
  console.log('label', label);
  return (<TextField
    floatingLabelText={label}
    hintText={label}
    className={styles.inputTextBox}
    floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
    errorStyle={styles1.errorInputStyle}
    errorText={touched && error}
    inputStyle={styles1.borderGrey}
    floatingLabelStyle={styles1.labelStyle}
    floatingLabelShrinkStyle={styles1.labelShrinkStyle}
    underlineFocusStyle={styles1.errorUnderline}
    {...input}
  />)
};

const renderPasswordField = ({ label, input, meta: { touched, error } }: Props) =>
  {
	return (<PasswordField
    floatingLabelText={label}
    className={styles.inputTextBox_Password}
    errorStyle={styles1.errorInputStyle}
    visibilityIconStyle={{
      marginTop: '-10px',
      opacity: '1'
    }}
    floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
    fullWidth
    textFieldStyle={styles1.borderGrey}
    floatingLabelStyle={styles1.labelStyle}
    floatingLabelShrinkStyle={styles1.labelShrinkStyle}
    underlineFocusStyle={styles1.errorUnderlinePwd}
    errorText={touched && error}
    placeholder={label}
    {...input}
  />)
};

const renderCheckbox = ({ input, label }) => (
  <Checkbox
    label={label}
    checked={input.value ? true : false}
    onCheck={input.onChange}
    {...input}
  />
)

const renderRewardTextField = ({ label, input, meta: { touched, error } }: Props) => {
  console.log('label', label);
  return (<TextField
    hintText="9101000389891796"
    className={styles.rewardsText}
    hintText= {label}
    floatingLabelText={label}
    floatingLabelStyle={{
                top: '29px',
                left: '15px',
                fontWeight: 'normal',
                border: 'none'
              }}
              floatingLabelFocusStyle={{
                color: '#a9aaa8',
                left: '15px',
                paddingBottom: '5px'
              }}
              style={{
                width: '100%',
                height: '56px',
                border: '1px solid black',
                marginTop: '10px'
              }}
    errorText={touched && error}
    errorStyle={styles1.errorInputStyleRewards}
    {...input}
  />)
};

class CreateForm extends PureComponent<Props> {

  submitFormHandler = () => {
    console.log('submitFormHandler');
    const { handleSubmit, SubmitStatus} = this.props;
    handleSubmit();
    if (SubmitStatus) {
      console.log('SubmitStatus ', SubmitStatus);
    }
  }

  state = { activeIndex: 0 }

  handleClick = (e, titleProps) => {
    const { index } = titleProps
    const { activeIndex } = this.state
    const newIndex = activeIndex === index ? -1 : index
    this.setState({ activeIndex: newIndex })
  }

  render() {
    const { activeIndex} = this.state
    console.log('CreateForm props', this.props);
    console.log('SubmitStatus props', this.props.SubmitStatus);
    const { data, handleSubmit, pristine, reset, submitting } = this.props;

    var arrowButton;
    if (activeIndex==0) {
      arrowButton = <div className={styles.arrowDownPosition}><svg width="24" height="24" viewBox="0 0 24 24"><path d="M7.41 15.41L12 10.83l4.59 4.58L18 14l-6-6-6 6z"/></svg></div>;
    } else {
      arrowButton = <div className={styles.arrowUpPosition}><svg width="24" height="24" viewBox="0 0 24 24"><path d="M7.41 7.84L12 12.42l4.59-4.58L18 9.25l-6 6-6-6z"/></svg></div>;
    }
    return (
      <form>
        <div>
          <div style={{ paddingBottom: '20px' }}>
            <Field
              name="firstName"
              component={renderTextField}
              label={data.mf_registration_firstName}
            />
            <Field
              name="lastName"
              component={renderTextField}
              label={data.mf_registration_lastName}
            />
            <Field
              name="postalCode"
              component={renderTextField}
              label={data.mf_registration_zip}
            />
            <Field
              name="phoneNumber"
              component={renderTextField}
              label={data.mf_registration_phone}
            />
            <Field
              name="email"
              component={renderTextField}
              label={data.mf_registration_email}
            />
            <Field
              name="password"
              component={renderPasswordField}
              label={data.mf_registration_password}
            />
          </div>
         <div className={styles.regRewardSection}>
            <Accordion>
            <Accordion.Title active={activeIndex === 0} index={0} onClick={this.handleClick}>
            <div className={styles.regRewardSectionTop}>
              {data.mf_registration_rewards}
            {arrowButton}
            </div>
            </Accordion.Title>
            <Accordion.Content active={activeIndex === 0}>
            <div className={styles.regRewardSectionMid}>
              {data.mf_registration_rewards_msg}
            </div>
            <Field
              name="reward"
              component={renderRewardTextField}
              label={data.mf_registration_rewards_textbox_lbl}
            />
            <div className={styles.regAZMember_Error}>
            {data.mf_registration_rewards_msg}
            </div>
            </Accordion.Content>
            </Accordion>
          </div>
          <div className={styles.regSubscription}>
            <div className={styles.offerCheckBox}>
              <Field
                name="subscribe"
                component={renderCheckbox}
              />
            </div>
            <div className={styles.receiveOffer}>
              {data.mf_registration_privacy}
              <a
                href="/readYourPolicy"
                style={{
                  display: 'block',
                  textDecoration: 'underline',
                  color: '#333'
                }}
              >
                {data.mf_registration_privacy_2}
              </a>
            </div>
            <div className={styles.regReadTerms}>
              {data.mf_registration_TermsandConditions}
              <a href="/termsAndConditions">
                {data.mf_registration_TermsandConditions_2}
              </a>
            </div>
            <div className={styles.regButtonSection}>
              <RaisedButton
                onClick={this.submitFormHandler}
                // disabled={pristine || submitting}
                label={data.mf_registration_createAccount}
                className={styles.regPrimaryBtn}
              />
              <RaisedButton
                disabled={pristine || submitting}
                label={data.mf_registration_cancel}
                className={styles.regSecondaryBtn}
              />
            </div>
            <div className={styles.regSignInLink}>
              {data.mf_registration_SignIn}
              <a href="/signIn">{data.mf_registration_SignIn_2}</a>
            </div>
          </div>
        </div>
      </form>
    );
  }
}

CreateForm = reduxForm({
  form: 'createFormValues',
  validate
})(CreateForm);
const selector = formValueSelector('createFormValues');

CreateForm = connect(state => {
  return {
    initialValues: state.formInfo.defaultFormData,
    formValues: state.form.createFormValues && state.form.createFormValues.values,
    SubmitStatus: state.formInfo.SubmitStatus
  };
})(CreateForm);

export default CreateForm;
